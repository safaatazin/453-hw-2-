
#include <glad/gl.h> // Must be first!
#include <SFML/Graphics.hpp>
#include <thread>
#include <atomic>
#include <iostream>
#include "triangle.h"

//safaa changed
#include <fstream>//for glyph files 
#include <string>//stroing sentences 
#include <vector>
#include <algorithm>
#include <limits>
#include <memory>


//letters that will bve stored to drw on the screen 
std::vector<sf::VertexArray> letterShapes;

// so we can zoom and scroll text we start at 1 of zoom (so normal size) and 0 of scroll (so no scrolling yet ))
std::atomic<float> zoomLevel(1.0f);
std::atomic<float> scrollX(0.0f);

 // Cubic Bezier curve calculation 
 sf::Vector2f bezierPoint(
     sf::Vector2f p0,//starting
     sf::Vector2f p1,//first point 
     sf::Vector2f p2,
     sf::Vector2f p3,//last point 
     float t)//position from 0 to 1 on curve 
 {
     // calculates how much each point contributes 
     float k1 = (1 - t) * (1 - t) * (1 - t);
     float k2 = 3 * (1 - t) * (1 - t) * t;
     float k3 = 3 * (1 - t) * t * t;
     float k4 = t * t * t;

     // Calculate the point on the curve
     sf::Vector2f point =
         p0 * k1 +
         p1 * k2 +
         p2 * k3 +
         p3 * k4;

     return point;
 }



 // Read one glyph and add its paths to the collection
bool loadGlyph(
    char letter, //letter we wanna load 
    float cursorX,//position of letter 

    std::vector<std::vector<sf::Vector2f>>& allPaths)
{
    //makes character to ASCII numbers 
    int ascii = static_cast<unsigned char>(letter);
//finds filew with matching ASCII number 
    std::string filename =
        "fonts/cmuntt/gly_" + std::to_string(ascii);

    std::ifstream file(filename);

    if (!file.is_open()) {
        std::cerr << "Could not find/open " << filename << std::endl;
        return false;
    }

//STORES points for one path of the letter 
    std::vector<sf::Vector2f> points;
//tracks our current position on the path and where we started the path (we we can close it too)
    sf::Vector2f currentPoint(0.f, 0.f);
    sf::Vector2f startPoint(0.f, 0.f);

    char command;



    //what to do in the opened file for each instruction 
    while (file >> command) {
//moves to new starting point 
        if (command == 'M') {

            // Save  previous path before starting another
            if (!points.empty()) {
                allPaths.push_back(points);
                points.clear();
            }

            float x, y;
            file >> x >> y;

            currentPoint = sf::Vector2f(x + cursorX, y);
            startPoint = currentPoint;

            points.push_back(currentPoint);
        }

        else if (command == 'L') {

            float x, y;
            file >> x >> y;

            currentPoint = sf::Vector2f(x + cursorX, y);
            points.push_back(currentPoint);
        }

        else if (command == 'C') {

            float x1, y1, x2, y2, x3, y3;

            file >> x1 >> y1
                 >> x2 >> y2
                 >> x3 >> y3;

            sf::Vector2f p1(x1 + cursorX, y1);
            sf::Vector2f p2(x2 + cursorX, y2);
            sf::Vector2f p3(x3 + cursorX, y3);

            // Approximate the curve with 25 line segments
            for (int i = 1; i <= 25; i++) {

                float t = static_cast<float>(i) / 25.f;

                sf::Vector2f p = bezierPoint(
                    currentPoint, p1, p2, p3, t
                );

                points.push_back(p);
            }

            currentPoint = p3;
        }

        else if (command == 'Z') {
            points.push_back(startPoint);
            currentPoint = startPoint;

            allPaths.push_back(points);
            points.clear();
        }
    }

    // we store final paths even if not closed 
    if (!points.empty()) {
        allPaths.push_back(points);
    }

    file.close();
    return true;
}






void renderingThread( sf::RenderWindow& window,std::atomic<bool>& running,std::atomic<bool>& contextReady)
{
    if (!window.setActive(true)) {
        std::cerr << "CRITICAL: Thread failed to claim context!"<< std::endl;
        running = false;
        contextReady = true;
        return;
    }

    contextReady = true;

    // Initialize GLAD with SFML's function loader
    if (!gladLoadGL(sf::Context::getFunction)) {
        std::cerr << "Failed to initialize GLAD!" << std::endl;
       return;
    }

    // Hard verification check:
    if (sf::Shader::isAvailable()) {
        std::cout << "SUCCESS: Shaders are fully available on this thread!" << std::endl;
    } else {
        std::cerr << "ERROR: Context is active on thread, but driver reports NO SHADERS." << std::endl;
    }

      
    // match OpenGL's -1 to 1 canonical view with the Y axis pointing up.
	// Passing a negative height (-2.f) flips the Y-axis upside down!
	// Now: Top-Left is (-1.0, 1.0) and Bottom-Right is (1.0, -1.0)
	sf::View view(sf::Vector2f(0.f, 0.f), sf::Vector2f(2.f, -2.f));
	window.setView(view);

    // Background and alpha blending
    glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    while (running) {
        // draw...

        glClear(GL_COLOR_BUFFER_BIT);
        window.pushGLStates(); // Save OpenGL states before drawing SFML shapes

        // Apply zoom and horizontal scrolling
        sf::Transform transform;

        transform.translate(
            sf::Vector2f(scrollX.load(), 0.f)
        );

        transform.scale(
            sf::Vector2f(zoomLevel.load(), zoomLevel.load())
        );

        sf::RenderStates states;
        states.transform = transform;

        for (const auto& shape : letterShapes) {
            window.draw(shape, states);
        }

        window.popGLStates();// Restore OpenGL states after drawing SFML shapes
        window.display();
    }
    window.setActive(false);
}


int main(int argc, char* argv[])
{
    if (argc < 2) {
        std::cerr << "Add your text " << std::endl;
        return -1;
    }

    
    sf::ContextSettings settings;
    settings.majorVersion = 2;
    settings.minorVersion = 1;
    settings.attributeFlags = sf::ContextSettings::Default;

    sf::RenderWindow window(
        sf::VideoMode({800, 800}),
        "SFML + GLAD (OpenGL 2.1)",
        sf::Style::Default,
        sf::State::Windowed,
        settings
    );
    // set additional window properties
    window.setKeyRepeatEnabled(false);


    
    // DO NOT LIMIT FRAME RATE! Use elapsed time to control updates.

    // deactivate its OpenGL context
    if (!window.setActive(false)) {
        std::cerr << "Error setting up window, could not deactivate context" << std::endl;
        return -1;
    }



    std::string text = argv[1];

    // Collect every path from every letter
    std::vector<std::vector<sf::Vector2f>> allPaths;

// initial cursor position for first letter, and the spacing bw letters
    float cursorX = 0.0f;
    const float characterSpacing = 0.50f;

    for (char letter : text) {

        // A space advances the cursor but draws nothing
        if (letter == ' ') {
            cursorX += characterSpacing;
            continue;
        }

        std::cout << "Loading character: "
                  << letter << std::endl;

        loadGlyph(letter, cursorX, allPaths);

        // Move to the next character
        cursorX += characterSpacing;
    }

    if (allPaths.empty()) {
        std::cerr << "No glyph paths were loaded!" << std::endl;
        return 1;
    }

    // Find limits of all points so we know scaling and centering 
    float minX = std::numeric_limits<float>::max();
    float maxX = std::numeric_limits<float>::lowest();
    float minY = std::numeric_limits<float>::max();
    float maxY = std::numeric_limits<float>::lowest();

    for (const auto& path : allPaths) {
        for (const auto& point : path) {

            minX = std::min(minX, point.x);
            maxX = std::max(maxX, point.x);

            minY = std::min(minY, point.y);
            maxY = std::max(maxY, point.y);
        }
    }

    float textWidth = maxX - minX;
    float textHeight = maxY - minY;

    // put full sentence in the center 
    // small gap around letters so they dont touch the window edges
    float scaleX = 1.9f / std::max(textWidth, 0.01f);
    float scaleY = 1.9f / std::max(textHeight, 0.01f);

    float initialScale = std::min(scaleX, scaleY);

    // Center 
    float centerX = (minX + maxX) / 2.0f;
    float centerY = (minY + maxY) / 2.0f;

    // Convert glyph paths to SFML 
    for (const auto& outline : allPaths) {

        sf::VertexArray strip(sf::PrimitiveType::LineStrip);

        for (const auto& pt : outline) {

            sf::Vector2f pos(
                (pt.x - centerX) * initialScale,
                (pt.y - centerY) * initialScale
            );

            sf::Vertex vertex;
            vertex.position = pos;
            vertex.color = sf::Color::Red;

            strip.append(vertex);
        }

        letterShapes.push_back(strip);
    }

    std::cout << "Number of paths: "
              << letterShapes.size() << std::endl;

    std::cout << "Initial scale: "
              << initialScale << std::endl;
    





    std::atomic<bool> running(true);
    std::atomic<bool> contextReady(false);

    // Launch the rendering thread
    std::thread thread(
        renderingThread,
        std::ref(window),
        std::ref(running),
        std::ref(contextReady)
    );




    // CRUCIAL: Pause the main thread until the rendering thread has successfully claimed the context.
    // This prevents pollEvent() from clashing with setActive(true) during initialization.
    while (!contextReady) {
        std::this_thread::yield();
    }


    



while (running && window.isOpen()) {

        while (const std::optional event = window.pollEvent()) {

            if (event->is<sf::Event::Closed>()) {
                running = false;
                break;
             
            }
                

            // Keyboard for scaling and scrolling 
            if (const auto* keyPressed = event->getIf<sf::Event::KeyPressed>()) {

                // Up arrow: zoom in
                if (keyPressed->code == sf::Keyboard::Key::Up) {
                    zoomLevel = std::min(
                        zoomLevel.load() * 1.1f, 20.0f
                    );
                }

                // Down arrow: zoom out
                else if (keyPressed->code == sf::Keyboard::Key::Down) {
                    zoomLevel = std::max(zoomLevel.load() / 1.1f, 0.1f );
                }

                // Left arrow: scroll left
                else if (keyPressed->code == sf::Keyboard::Key::Left) {
                    scrollX = scrollX.load() - 0.1f;
                }

                // Right arrow: scroll right
                else if (keyPressed->code == sf::Keyboard::Key::Right) {
                    scrollX = scrollX.load() + 0.1f;
                }

                // Escape: close  program
                else if (keyPressed->code == sf::Keyboard::Key::Escape) {
                    running = false;
                    break;
                }
            }
         
    }}


    // Wait for the rendering thread to finish
    running = false;

    if (thread.joinable()) {
        thread.join();
    }
    window.close();
    return 0;
}
